# HOTEL MANAGEMENT SYSTEM
## Video Demo: https://youtu.be/6lE8gIOJdRE
### Description:
I've made the Hotel Management system in C language this project performs the basic functionality of a hotel management e.g booking a room,
deleting customer record etc. i will explain the functionality of project in modules which are as follows

USER AUTHENTICATION:
first of all the program will ask you to enter your username and password and after entering the correct details you would get access to the management menu.

i.	BOOK A ROOM:
After selecting the book a room option e.g. by pressing 1 you will be asked to enter user information which are as follows
Enter Room Number
Enter Name
Enter address
Enter Phone number
Enter Nationality
Enter email
Enter no of days
Enter Arrival date
After entering all the details you will go back to main menu

ii.	VIEW CUSTOMER RECORD:
By selecting the view customer option e.g. pressing 2 you will shown the records of all the customers


iii.	DELETE CUSTOMER RECORD:

After selecting the delete customer record e.g. pressing 3 you will be asked to  enter the room no of the customer to deleted if the room no exist the record will be deleted else you will see a warning “record of customer not found”.


iv.	SEARCH CUSTOMER RECORD:

After selecting the search customer record e.g. pressing 4 you will be asked to enter room no of the customer searched if the room no exists you will shown the complete record of the customer else you will get a warning  “requested customer could not be found”

v.	EDIT RECORD:

After selecting edit customer record e.g. pressing 5 you will be asked to enter room no of the customer sto be edited  if the room no exists you can edit the  record of the customer else you will get a warning  “the record doesn’t exist”

vi.	EXIT:

After selecting the exit option e.g. pressing 6 the program will stop running 
